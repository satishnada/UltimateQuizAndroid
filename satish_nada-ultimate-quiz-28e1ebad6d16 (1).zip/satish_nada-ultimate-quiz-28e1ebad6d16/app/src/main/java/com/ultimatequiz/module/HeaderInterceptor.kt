package com.ultimatequiz.module

import com.ultimatequiz.data.preferences.PreferenceProvider
import okhttp3.Credentials
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response

class HeaderInterceptor(private val preferenceProvider: PreferenceProvider) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val authToken = Credentials.basic("candidate", "Rc@2020")
        /*if (chain.request().url.toString().contains("oauth/token")) {
            val newRequest: Request = chain.request().newBuilder()
                .addHeader("Authorization", authToken)
                .build()
            return chain.proceed(newRequest)
        } else {*/
            val newRequest: Request = chain.request().newBuilder()
                //.addHeader("Authorization", "bearer " + preferenceProvider.getAuthToken())
                .build()
            return chain.proceed(newRequest)
        //}
    }
}