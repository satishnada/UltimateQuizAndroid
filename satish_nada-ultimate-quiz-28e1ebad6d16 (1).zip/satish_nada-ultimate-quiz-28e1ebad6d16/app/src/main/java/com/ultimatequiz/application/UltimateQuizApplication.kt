package com.ultimatequiz.application

import androidx.multidex.MultiDexApplication
import com.ultimatequiz.module.appModules
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class UltimateQuizApplication : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()
        // Adding Koin modules to our application
        startKoin {
            androidContext(this@UltimateQuizApplication)
            modules(appModules)
        }
    }
}