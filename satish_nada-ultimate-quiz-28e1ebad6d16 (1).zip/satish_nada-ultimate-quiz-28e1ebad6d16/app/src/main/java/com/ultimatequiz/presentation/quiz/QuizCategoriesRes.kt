package com.ultimatequiz.presentation.quiz

import com.google.gson.annotations.SerializedName

data class QuizCategoriesRes(
    @SerializedName("data")
    val quizCategoryList: ArrayList<QuizCategory>,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class QuizCategory(
        @SerializedName("rcQuizCategoryId")
        val quizCategoryId: Int,
        @SerializedName("rcQuizCategoryName")
        val quizCategoryName: String,
        @SerializedName("rcLangId")
        val langId: Int,
        @SerializedName("rcLangName")
        val rcLangName: String
    )
}