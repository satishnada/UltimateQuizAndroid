package com.ultimatequiz.presentation.dashboard.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ultimatequiz.R
import com.ultimatequiz.presentation.dashboard.GetPropertyByUserResModel
import kotlinx.android.synthetic.main.item_property_list.view.*
import kotlin.properties.Delegates

class PropertyAdapter(private val onPropertyClicked: (property: GetPropertyByUserResModel.Data) -> Unit) :
    RecyclerView.Adapter<PropertyAdapter.MyViewHolder>() {

    // Our data list is going to be notified when we assign a new list of data to it
    private var datalist: List<GetPropertyByUserResModel.Data> by Delegates.observable(emptyList()) { _, _, _ ->
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_property_list, parent, false)
        val holder = MyViewHolder(view)

        return holder
    }

    override fun getItemCount(): Int = datalist.size

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        // Verify if position exists in list
        if (position != RecyclerView.NO_POSITION) {
            val itemData: GetPropertyByUserResModel.Data = datalist[position]
            holder.bind(itemData)

            holder.itemView.img_snapshot.setOnClickListener {
                if (holder.adapterPosition != RecyclerView.NO_POSITION) {
                    onPropertyClicked.invoke(datalist[holder.adapterPosition])
                }
            }
        }
    }

    // Update recyclerView's data
    fun updateData(newdatalist: List<GetPropertyByUserResModel.Data>) {
        datalist = newdatalist
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(itemData: GetPropertyByUserResModel.Data) {
            itemView.txt_property_name.text = itemData.propertyName
        }
    }
}