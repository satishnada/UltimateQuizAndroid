package com.ultimatequiz.presentation.gkchallenge

import com.google.gson.annotations.SerializedName

data class QuestionsForGKRes(
    @SerializedName("data")
    val quizLevelList: ArrayList<Questions>,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class Questions(
        @SerializedName("rcQuestionId")
        val quizLevelId: Int,
        @SerializedName("rcQuestionCategoryId")
        val quizCategoryId: Int,
        @SerializedName("rcLangId")
        val quizLevelName: Int,
        @SerializedName("rcQuestionText")
        val quizLevelQueCount: String,
        @SerializedName("rcQuestionOpt1")
        val rcQuestionOpt1: String,
        @SerializedName("rcQuestionOpt2")
        val rcQuestionOpt2: String,
        @SerializedName("rcQuestionOpt4")
        val rcQuestionOpt4: String,
        @SerializedName("rcQuestionOpt5")
        val rcQuestionOpt5: String
    )
}