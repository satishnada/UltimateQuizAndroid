package com.ultimatequiz.presentation.dashboard


import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.utils.SingleLiveEvent

class DashboardViewModel(private val dataRepository: DataRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()
    val navigateToDashboard = SingleLiveEvent<String>()

    init {

    }

    fun onTopBack(){
        navigateToDashboard.value = "TOP_BACK"
    }

    fun onTopBalanceClick(){
        navigateToDashboard.value = "TOP_BALANCE"
    }

    fun onLanguageClick(){
        navigateToDashboard.value = "LANGUAGE"
    }

    fun onStatsInfoClick(){
        navigateToDashboard.value = "STATS"
    }

    fun onLeaderBoardClick(){
        navigateToDashboard.value = "LEADER_BOARD"
    }

    fun onShareAppClick(){
        navigateToDashboard.value = "SHARE_APP"
    }

    fun onEnjoyApp(){
        navigateToDashboard.value = "ENJOY_APP"
    }

    fun onPlayGame(){
        navigateToDashboard.value = "PLAY_GAME"
    }

    /*fun getPropertyByUser(getPropertyByuserReqModel: GetPropertyByuserReqModel) {

        showLoading.value = true

        launch {

            val result = withContext(Dispatchers.IO) {
                dataRepository.getPropertyByUser(getPropertyByuserReqModel)
            }
            showLoading.value = false
            when (result) {
                is UseCaseResult.Success -> datalist.value = result.data.data
                is UseCaseResult.Error -> showError.value = result.exception.message
            }
        }

    }*/

}
