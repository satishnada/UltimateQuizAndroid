package com.ultimatequiz.presentation.login

import com.google.gson.annotations.SerializedName

data class LoginResModel(
    @SerializedName("data")
    val data: ArrayList<Data>,
    @SerializedName("statusCode")
    val statusCode: String,
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class Data(
        @SerializedName("rcCountryId")
        val rcCountryId: Int,
        @SerializedName("rcCountryName")
        val rcCountryName: String
    )
}