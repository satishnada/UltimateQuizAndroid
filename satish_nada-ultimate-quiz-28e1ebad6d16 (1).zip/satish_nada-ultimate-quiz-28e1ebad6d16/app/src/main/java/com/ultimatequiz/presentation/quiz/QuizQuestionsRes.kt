package com.ultimatequiz.presentation.quiz

import com.google.gson.annotations.SerializedName

data class QuizQuestionsRes(
    @SerializedName("data")
    val questionList: ArrayList<Question>,
    @SerializedName("statusCode")
    val statusCode: String,
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class Question(
        @SerializedName("rcQuestionId")
        val rcQuestionId: Int,
        @SerializedName("rcQuestionCategoryId")
        val rcQuestionCategoryId: Int,
        @SerializedName("rcLangId")
        val rcLangId: Int,
        @SerializedName("rcQuestionText")
        val rcQuestionText: String,
        @SerializedName("rcQuestionOpt1")
        val rcQuestionOpt1: String,
        @SerializedName("rcQuestionOpt2")
        val rcQuestionOpt2: String,
        @SerializedName("rcQuestionOpt3")
        val rcQuestionOpt3: String,
        @SerializedName("rcQuestionOpt4")
        val rcQuestionOpt4: String,
        @SerializedName("rcQuestionOpt5")
        val rcQuestionOpt5: String,
        @SerializedName("options")
        val options: ArrayList<Options>,
        @SerializedName("rcCorrectOpt")
        val rcCorrectOpt: Int
    ){
        data class Options(
            @SerializedName("id")
            val id: Int,
            @SerializedName("option")
            val option: String,
            @SerializedName("true")
            val truee: Boolean,
        )
    }
}