package com.ultimatequiz.presentation.learderboard

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ultimatequiz.R
import kotlinx.android.synthetic.main.item_gk_challenge_level.view.txtLevel
import kotlinx.android.synthetic.main.item_user_ranker.view.*

class TopUserListAdapter(
    val items: ArrayList<LeaderBoardInfoRes.LeaderBoard>,
    val context: Context
) :
    RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.item_user_ranker,
                parent,
                false
            )
        )
    }

    fun setDataList(levelList: ArrayList<LeaderBoardInfoRes.LeaderBoard>) {
        items.clear()
        items.addAll(levelList)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return items.size;
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txtLevel?.text = (position + 1).toString()
        holder.txtUserName?.text = items[position].userName
        holder.txtQuestionValue?.text = items[position].totalCoinEarn.toString()
    }

}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    // Holds the TextView that will add each animal to
    val txtLevel = view.txtLevel
    val txtUserName = view.txtUserName
    val txtQuestionValue = view.txtQuestValue
    val imgUser = view.imgUser
}