package com.ultimatequiz.presentation.login

import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.preferences.PreferenceProvider
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.presentation.gkchallenge.QuizLevelRes
import com.ultimatequiz.presentation.language.LanguageRes
import com.ultimatequiz.presentation.learderboard.LeaderBoardInfoRes
import com.ultimatequiz.presentation.quiz.QuizCategoriesRes
import com.ultimatequiz.presentation.quiz.QuizQuestionsRes
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import com.ultimatequiz.presentation.statsinfo.QuizStateInfoRes
import com.ultimatequiz.utils.SingleLiveEvent
import com.ultimatequiz.utils.UseCaseResult.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginViewModel(private val dataRepository: DataRepository,private var preferenceProvider: PreferenceProvider) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()
    val loginResModel = SingleLiveEvent<LoginResModel>()
    val countriesRes = SingleLiveEvent<CountriesRes>()
    val languageRes = SingleLiveEvent<LanguageRes>()
    val quizLevelRes = SingleLiveEvent<QuizLevelRes>()
    val questionCategoriesRes = SingleLiveEvent<QuestionCategoriesRes>()
    val quizCategoriesRes = SingleLiveEvent<QuizCategoriesRes>()
    val quizStateInfoRes = SingleLiveEvent<QuizStateInfoRes>()
    val leaderBoardInfoRes = SingleLiveEvent<LeaderBoardInfoRes>()
    val accessTokenResModel = SingleLiveEvent<AccessTokenResModel>()
    val navigateToDashboard = SingleLiveEvent<String>()
    val quizQuestionRes = SingleLiveEvent<QuizQuestionsRes>()

    init {

    }

    fun saveToken(token:String){
        preferenceProvider.setAuthToken(token)
    }

    fun saveSession(boolean: Boolean){
        preferenceProvider.setSession(boolean)
    }

    fun getSession():Boolean?{
        return preferenceProvider.getSession()
    }

    fun doBackPress(loginReqModel: LoginReqModel) {
        navigateToDashboard.value = "BACK_PRESS"
    }

    fun onCountrySelection(loginReqModel: LoginReqModel) {
        navigateToDashboard.value = "ON_COUNTRY_SELECTION"
    }

    fun onLoginClick() {
        navigateToDashboard.value = "ON_LOGIN_CLICK"
    }

    fun doLogin(loginReqModel: LoginReqModel) {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.loginAsync(loginReqModel)
            }
            showLoading.value = false
            when (result) {
                is Success -> loginResModel.value =
                    result.data
                is Error -> showError.value = result.exception.message
            }
        }

    }

    fun getAccessToken() {
        showLoading.value = true
        val token: TokenReqModel? = TokenReqModel()
        token?.username = "admin"
        token?.password = "Rc@2020"
        token?.grant_type = "password"

        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getAccessToken(token)
            }
            showLoading.value = false
            when (result) {
                is Success -> accessTokenResModel.value =
                    result.data
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getCountryList() {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getCountryList()
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    countriesRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getLanguageList() {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getLanguageList()
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    languageRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }


    fun getAllQuizLevelList() {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getAllQuizLevelList()
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    quizLevelRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getQuestionCategoryList() {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getQuestionCategoryList()
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    questionCategoriesRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getQuestionCategoryListByLanguageId(url: String) {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getQuizStateInfo(url)
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    quizStateInfoRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getQuizCategoryList() {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getQuizCategoryList()
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    quizCategoriesRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getQuizStateInfo(url: String) {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getQuizStateInfo(url)
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    quizStateInfoRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getLeaderBoardInfo() {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getLeaderBoardInfo()
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    leaderBoardInfoRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getQuestionForGKUser(url:String) {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getQuestionForGKUser(url)
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    quizQuestionRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }

    fun getQuestionForUser(url:String) {
        showLoading.value = true
        launch {
            val result = withContext(Dispatchers.IO) {
                dataRepository.getQuestionForUser(url)
            }
            showLoading.value = false
            when (result) {
                is Success -> {
                    quizQuestionRes.value = result.data
                }
                is Error -> showError.value = result.exception.message
            }
        }
    }


}
