package com.ultimatequiz.presentation.statsinfo

import com.google.gson.annotations.SerializedName

data class QuizStateInfoRes(
    @SerializedName("data")
    val quizStateInfo: QuizStateInfo,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class QuizStateInfo(
        @SerializedName("correctAns")
        val correctAns: Int,
        @SerializedName("wrongAns")
        val wrongAns: Int,
        @SerializedName("totalPlayed")
        val totalPlayed: Int
    )
}