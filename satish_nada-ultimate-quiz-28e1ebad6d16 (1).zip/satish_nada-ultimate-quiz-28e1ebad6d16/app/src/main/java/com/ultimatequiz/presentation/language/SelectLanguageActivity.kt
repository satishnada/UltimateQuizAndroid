package com.ultimatequiz.presentation.language

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivitySelectLangaugeBinding
import com.ultimatequiz.presentation.learderboard.LeaderBoardActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel

class SelectLanguageActivity : AppCompatActivity() {

    private val viewModel : SelectLanguageViewModel by viewModel()
    lateinit var binding : ActivitySelectLangaugeBinding
    private val viewModelApi: LoginViewModel by viewModel()
    private val TAG = SelectLanguageActivity.javaClass.canonicalName

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, SelectLanguageActivity::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@SelectLanguageActivity,R.layout.activity_select_langauge)
        binding.mLanguageViewModel = viewModel
        initViewModel()
    }

    private fun initViewModel(){

        viewModel.navigate.observe(this, Observer() {
            if (it == "ENGLISH"){
                finish()
            }else if (it == "HINDI"){
                finish()
            }else if (it == "GUJARATI"){
                finish()
            }else if(it == "TopBack"){
                finish()
            }
        })

        showProgress()
        viewModelApi.getLanguageList()

        viewModelApi.showError.observe(this, Observer { showError ->
            showProgress()
            if (showError.contains("HTTP 401")){
                viewModelApi.getAccessToken()
            }else{
                Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
            }
        })

        viewModelApi.languageRes.observe(this, Observer {
            showProgress()
            if (it.statusCode.equals("SUCCESS", true)) {
                Log.e(TAG, it.toString())

            } else {
                Toast.makeText(this, it.statusMessage, Toast.LENGTH_SHORT).show()
                viewModelApi.getAccessToken()
            }
        })

        viewModelApi.accessTokenResModel.observe(this, Observer {
            showProgress()
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            viewModelApi.saveToken(it.accessToken)
            viewModelApi.getLanguageList()
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }

}
