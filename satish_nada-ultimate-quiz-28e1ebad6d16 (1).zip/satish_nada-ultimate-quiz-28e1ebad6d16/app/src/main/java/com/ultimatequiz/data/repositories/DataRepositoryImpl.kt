package com.ultimatequiz.data.repositories

import android.util.Log
import com.ultimatequiz.data.remote.WebApi
import com.ultimatequiz.presentation.gkchallenge.QuizLevelRes
import com.ultimatequiz.presentation.language.LanguageRes
import com.ultimatequiz.presentation.learderboard.LeaderBoardInfoRes
import com.ultimatequiz.presentation.login.*
import com.ultimatequiz.presentation.quiz.QuizCategoriesRes
import com.ultimatequiz.presentation.quiz.QuizQuestionsRes
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import com.ultimatequiz.presentation.statsinfo.QuizStateInfoRes
import com.ultimatequiz.utils.UseCaseResult

class DataRepositoryImpl(private val webApi: WebApi) : DataRepository {
    override suspend fun getCountryList(): UseCaseResult<CountriesRes> {
        return try {
            val result = webApi.getCountryList()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun loginAsync(loginReqModel: LoginReqModel): UseCaseResult<LoginResModel> {
        /*
         We try to return a list of cats from the API
         Await the result from web service and then return it, catching any error from API
         */
        return try {
            var urlParam : String = "rcapp/ano/checkUserExistance/"+loginReqModel.deviceId+ "/" +loginReqModel.countryId+ "/" +loginReqModel.username
            val result = webApi.loginAsync(urlParam)
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            Log.d("catch", ex.toString())
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun userLogout(): UseCaseResult<LoginResModel> {
        TODO("Not yet implemented")
    }

    override suspend fun getLanguageList(): UseCaseResult<LanguageRes> {
        return try {
            val result = webApi.getLanguages()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getAllQuizLevelList(): UseCaseResult<QuizLevelRes> {
        return try {
            val result = webApi.getAllQuizLevel()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getQuestionCategoryList(): UseCaseResult<QuestionCategoriesRes> {
        return try {
            val result = webApi.getQuestionCategory()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getQuestionCategoryListByLanguageId(): UseCaseResult<QuestionCategoriesRes> {
        return try {
            val result = webApi.getQuestionCategoryByLanguageId()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getQuizCategoryList(): UseCaseResult<QuizCategoriesRes> {
        return try {
            val result = webApi.getQuizCategoryList()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getLeaderBoardInfo(): UseCaseResult<LeaderBoardInfoRes> {
        return try {
            val result = webApi.getLeaderBoardInfo()
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getQuestionForGKUser(url:String): UseCaseResult<QuizQuestionsRes> {
        return try {
            val result = webApi.getQuestionsForGKUser(url)
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getQuestionForUser(url:String): UseCaseResult<QuizQuestionsRes> {
        return try {
            val result = webApi.getQuestionsForUser(url)
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getQuizStateInfo(url:String): UseCaseResult<QuizStateInfoRes> {
        return try {
            val result = webApi.getQuizStateInfo(url)
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

    override suspend fun getAccessToken(tokenReqModel: TokenReqModel?): UseCaseResult<AccessTokenResModel> {
        return try {
            val result = webApi.getAccessToken(tokenReqModel?.grant_type,tokenReqModel?.username,tokenReqModel?.password)
            UseCaseResult.Success(result)
        } catch (ex: Exception) {
            UseCaseResult.Error(ex)
        }
    }

}