package com.ultimatequiz.presentation.login

import com.google.gson.annotations.SerializedName

data class TokenReqModel(
        @SerializedName("username") var username: String = "",
        @SerializedName("password") var password: String = "",
        @SerializedName("grant_type") var grant_type: String = ""
)