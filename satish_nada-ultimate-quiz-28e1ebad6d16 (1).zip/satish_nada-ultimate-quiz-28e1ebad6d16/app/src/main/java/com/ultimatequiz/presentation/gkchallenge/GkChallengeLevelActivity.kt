package com.ultimatequiz.presentation.gkchallenge

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityGkChallengeLevelBinding
import com.ultimatequiz.databinding.ActivitySelectGamesBinding
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.presentation.quiz.QuizActivity
import org.koin.android.viewmodel.ext.android.viewModel

class GkChallengeLevelActivity : AppCompatActivity() {

    val TAG = QuizActivity.javaClass.canonicalName
    private val viewModel : GkChallengeLevelViewModel by viewModel()
    lateinit var  binding : ActivityGkChallengeLevelBinding
    private val viewModelApi: LoginViewModel by viewModel()
    private var gkChallengeLevelAdapter:GkChallengeLevelAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@GkChallengeLevelActivity,R.layout.activity_gk_challenge_level)
        binding.mGkChalengeViewModel = viewModel
        initViewModel()
    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, GkChallengeLevelActivity::class.java)
        }
    }

    private fun initViewModel(){

        val levelList : ArrayList<QuizLevelRes.QuizLevel> = ArrayList();
        binding.recyclerViewLevel.layoutManager = LinearLayoutManager(this)
        gkChallengeLevelAdapter = GkChallengeLevelAdapter(levelList,this);
        binding.recyclerViewLevel.adapter = gkChallengeLevelAdapter

        viewModel.navigate.observe(this, Observer() {
            if (it == "SELECT_LEVEL"){
                finish()
            }else if(it == "TOP_BACK"){
                finish()
            }
        })

        viewModelApi.getAllQuizLevelList()

        viewModelApi.quizLevelRes.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.quizLevelList)
            gkChallengeLevelAdapter?.setDataList(it.quizLevelList)
        })

        viewModelApi.showError.observe(this, Observer { showError ->
            if (showError.contains("HTTP 401")){
                viewModelApi.getAccessToken()
            }else{
                Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
            }
        })

        viewModelApi.accessTokenResModel.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            viewModelApi.saveToken(it.accessToken)
            viewModelApi.getQuestionForUser("rcapp/rest/getQuestionForUser/1/1/1")
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

    }
}
