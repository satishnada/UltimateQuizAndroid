package com.ultimatequiz.presentation.learderboard

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityLeaderBoardBinding
import com.ultimatequiz.presentation.dashboard.DashboardActivity
import com.ultimatequiz.presentation.login.LoginActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel

class LeaderBoardActivity : AppCompatActivity() {

    private val viewModel : LeaderBoardViewModel by viewModel()
    private val viewModelApi: LoginViewModel by viewModel()
    lateinit var  binding : ActivityLeaderBoardBinding
    private val TAG = LeaderBoardActivity.javaClass.canonicalName
    private var topUserListAdapter : TopUserListAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@LeaderBoardActivity,R.layout.activity_leader_board)
        binding.mLeaderBoardViewModel = viewModel
        initViewModel()

    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, LeaderBoardActivity::class.java)
        }
    }

    private fun initViewModel(){

        val levelList : ArrayList<LeaderBoardInfoRes.LeaderBoard> = ArrayList();
        binding.recyclerUser.layoutManager = LinearLayoutManager(this)
        topUserListAdapter =  TopUserListAdapter(levelList,this)
        binding.recyclerUser.adapter = topUserListAdapter

        viewModel.navigate.observe(this, Observer() {
            if (it == "GK_QUIZ"){
                //startActivity(GkChallengeLevelActivity.getInstance(this).putExtra("IS_FROM",2))
            }else if (it == "QUIZ"){
                //startActivity(QuizActivity.getInstance(this).putExtra("IS_FROM",1))
            }else if (it == "SPINNER"){
                //startActivity(QuizActivity.getInstance(this))
            }else if(it == "TopBack"){
                finish()
            }
        })

        showProgress()
        viewModelApi.getLeaderBoardInfo()

        viewModelApi.showError.observe(this, Observer { showError ->
            Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
        })

        viewModelApi.leaderBoardInfoRes.observe(this, Observer {
            showProgress()
            if (it.statusCode.equals("SUCCESS", true)) {
                Log.e(TAG, it.toString())
                topUserListAdapter?.setDataList(it.leaderBoardsList.leaderBoardRankerList)

                val leaderBoard = it.leaderBoardsList.leaderBoardRanker[0]
                binding.txtUserName1.text = leaderBoard.userName
                binding.txtUserRank1.text = leaderBoard.totalCoinEarn.toString()

                val leaderBoard2 = it.leaderBoardsList.leaderBoardRanker[0]
                binding.txtUserName2.text = leaderBoard2.userName
                binding.txtUserRank2.text = leaderBoard2.totalCoinEarn.toString()

                val leaderBoard3 = it.leaderBoardsList.leaderBoardRanker[0]
                binding.txtUserName3.text = leaderBoard3.userName
                binding.txtUserRank3.text = leaderBoard3.totalCoinEarn.toString()

            } else {
                Toast.makeText(this, it.statusMessage, Toast.LENGTH_SHORT).show()
                viewModelApi.getAccessToken()
            }
        })

        viewModelApi.accessTokenResModel.observe(this, Observer {
            showProgress()
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            Preferences.saveAccessToken(this, it.accessToken)
            viewModelApi.saveToken(it.accessToken)
            viewModelApi.getLeaderBoardInfo()
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })
    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }
}
