package com.ultimatequiz.presentation.selectgames

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivitySelectGamesBinding
import com.ultimatequiz.presentation.category.CategoriesListActivity
import com.ultimatequiz.presentation.gkchallenge.GkChallengeLevelActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.presentation.quiz.QuizActivity
import com.ultimatequiz.presentation.statsinfo.StatsInfoActivity
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel

class SelectGamesActivity : AppCompatActivity() {

    private val viewModel : SelectGameViewModel by viewModel()
    lateinit var  binding : ActivitySelectGamesBinding
    private val viewModelApi: LoginViewModel by viewModel()
    val TAG = SelectGamesActivity.javaClass.canonicalName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@SelectGamesActivity,R.layout.activity_select_games)
        binding.mGameViewModel = viewModel
        initViewModel()
    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, SelectGamesActivity::class.java)
        }
    }

    private fun initViewModel(){

        viewModel.navigate.observe(this, Observer() {
            if (it == "GK_QUIZ"){
                startActivity(GkChallengeLevelActivity.getInstance(this).putExtra("IS_FROM",2))
            }else if (it == "QUIZ"){
                startActivity(CategoriesListActivity.getInstance(this))
            }else if (it == "SPINNER"){
                startActivity(CategoriesListActivity.getInstance(this))
            }else if(it == "TopBack"){
                finish()
            }
        })

        showProgress()
        viewModelApi.getAccessToken()

        viewModelApi.accessTokenResModel.observe(this, Observer {
            showProgress()
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            Preferences.saveAccessToken(this, it.accessToken)
            viewModelApi.saveToken(it.accessToken)
        })

        viewModel.showError.observe(this, Observer {
            showProgress()
        })

    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }
}
