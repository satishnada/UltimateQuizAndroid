package com.ultimatequiz.module

import com.google.gson.GsonBuilder
import com.ultimatequiz.BuildConfig
import com.ultimatequiz.data.preferences.PreferenceProvider
import com.ultimatequiz.data.remote.WebApi
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.data.repositories.DataRepositoryImpl
import com.ultimatequiz.presentation.category.CategoriesViewModel
import com.ultimatequiz.presentation.dashboard.DashboardViewModel
import com.ultimatequiz.presentation.gkchallenge.GkChallengeLevelViewModel
import com.ultimatequiz.presentation.language.SelectLanguageViewModel
import com.ultimatequiz.presentation.learderboard.LeaderBoardViewModel
import com.ultimatequiz.presentation.login.AuthViewModel
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.presentation.quiz.QuizViewModel
import com.ultimatequiz.presentation.redeem.RedeemViewModel
import com.ultimatequiz.presentation.selectgames.SelectGameViewModel
import com.ultimatequiz.presentation.statsinfo.StatsInfoViewModel
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

const val BASE_API_URL = "http://13.229.69.210:8080/"

val appModules = module {

    single {
        PreferenceProvider(context = get())
    }

    // The Retrofit service using our custom HTTP client instance as a singleton
    single() {
        createWebService<WebApi>(okHttpClient = createHttpClient(preferenceProvider = get() ), baseUrl = BASE_API_URL)
    }

    // Tells Koin how to create an instance of Repository
    factory<DataRepository> { DataRepositoryImpl(webApi = get()) }

    // Specific viewModel pattern to tell Koin how to build ViewModel
    viewModel {
        LoginViewModel(dataRepository = get(),preferenceProvider = get())
    }

    viewModel {
        DashboardViewModel(dataRepository = get())
    }

    viewModel {
        SelectLanguageViewModel(dataRepository = get())
    }

    viewModel {
        SelectGameViewModel(dataRepository = get())
    }

    viewModel {
        GkChallengeLevelViewModel(dataRepository = get())
    }

    viewModel {
        QuizViewModel(dataRepository = get())
    }

    viewModel {
        StatsInfoViewModel(dataRepository = get())
    }

    viewModel {
        LeaderBoardViewModel(dataRepository = get())
    }

    viewModel {
        RedeemViewModel(dataRepository = get())
    }

    viewModel {
        AuthViewModel(dataRepository = get())
    }

    viewModel {
        CategoriesViewModel(dataRepository = get())
    }

}

fun createHttpClient(preferenceProvider: PreferenceProvider): OkHttpClient {
    return OkHttpClient().newBuilder()
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .addInterceptor(provideLoggingInterceptor()!!)
        .addInterceptor(HeaderInterceptor(preferenceProvider))
        .build()
}

private fun provideLoggingInterceptor(): HttpLoggingInterceptor? = try {
    HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG)
            HttpLoggingInterceptor.Level.BODY
        else
            HttpLoggingInterceptor.Level.NONE
    }
} catch (e: Exception) {
    null
}

/* function to build our Retrofit service */
inline fun <reified T> createWebService(
    okHttpClient: OkHttpClient,
    baseUrl: String
): T {
    val retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
        .client(okHttpClient)
        .build()
    return retrofit.create(T::class.java)
}
