package com.ultimatequiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.ultimatequiz.presentation.dashboard.DashboardActivity
import com.ultimatequiz.presentation.login.LoginActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel

class SplashActivity : AppCompatActivity() {

    lateinit var handler: Handler
    lateinit var runnable: Runnable
    private val viewModel: LoginViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        handler = Handler()
        runnable = Runnable {
            if (!viewModel.getSession()!!) {
                startActivity(LoginActivity.getInstance(this).putExtra("IS_FROM",1))
                finish()
            } else {
                startActivity(DashboardActivity.getInstance(this))
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.postDelayed(runnable, 1500)
    }

    override fun onPause() {
        handler.removeCallbacks(runnable)
        super.onPause()
    }
}
