package com.ultimatequiz.presentation.dashboard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityDashboardBinding
import com.ultimatequiz.presentation.language.SelectLanguageActivity
import com.ultimatequiz.presentation.learderboard.LeaderBoardActivity
import com.ultimatequiz.presentation.login.LoginActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.presentation.redeem.RedeemActivity
import com.ultimatequiz.presentation.selectgames.SelectGamesActivity
import com.ultimatequiz.presentation.statsinfo.StatsInfoActivity
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel


class DashboardActivity : AppCompatActivity() {

    val TAG = DashboardActivity.javaClass.canonicalName
    private val viewModel: DashboardViewModel by viewModel()
    private val viewModelApi: LoginViewModel by viewModel()
    lateinit var binding: ActivityDashboardBinding

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, DashboardActivity::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =
            DataBindingUtil.setContentView(this@DashboardActivity, R.layout.activity_dashboard)
        binding.mDashboardViewModel = viewModel
        initViewModel()
    }

    private fun initViewModel() {

        viewModel.navigateToDashboard.observe(this, Observer() {
            if (it == "LANGUAGE") {
                startActivity(SelectLanguageActivity.getInstance(this))
            } else if (it == "STATS") {
                startActivity(StatsInfoActivity.getInstance(this))
            } else if (it == "LEADER_BOARD") {
                startActivity(LeaderBoardActivity.getInstance(this))
            } else if (it == "SHARE_APP") {
                val shareIntent = Intent()
                shareIntent.action = Intent.ACTION_SEND
                shareIntent.type="text/plain"
                shareIntent.putExtra(Intent.EXTRA_TEXT, "This is my text to send.");
                startActivity(Intent.createChooser(shareIntent,"Share App"))
            } else if (it == "PLAY_GAME") {
                startActivity(SelectGamesActivity.getInstance(this))
            } else if (it == "ENJOY_APP") {
                val shareIntent = Intent()
                shareIntent.action = Intent.ACTION_VIEW
                shareIntent.putExtra(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/developer?id=Sakariya+Brothers"))
                startActivity(shareIntent)
            }  else if (it == "TOP_BALANCE") {
                startActivity(RedeemActivity.getInstance(this))
            } else if (it == "TOP_BACK") {
                startActivity(LoginActivity.getInstance(this).putExtra("IS_FROM",2))
            }
        })

        showProgress()
        viewModelApi.getAccessToken()

        viewModelApi.accessTokenResModel.observe(this, Observer {
            showProgress()
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            Preferences.saveAccessToken(this, it.accessToken)
            viewModelApi.saveToken(it.accessToken)
        })

        viewModelApi.showError.observe(this, Observer {
            showProgress()
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }

}
