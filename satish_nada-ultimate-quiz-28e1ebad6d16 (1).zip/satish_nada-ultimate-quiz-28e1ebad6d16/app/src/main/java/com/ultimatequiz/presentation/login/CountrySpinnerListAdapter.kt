package com.ultimatequiz.presentation.login

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.ultimatequiz.R
import com.ultimatequiz.presentation.login.CountriesRes.*

class CountrySpinnerListAdapter(val context: Context, var countryList: ArrayList<Country>) :
    BaseAdapter() {

    val mInflater: LayoutInflater = LayoutInflater.from(context)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val vh: ItemRowHolder
        if (convertView == null) {
            view = mInflater.inflate(R.layout.spinner_item_layout, parent, false)
            vh = ItemRowHolder(view)
            view?.tag = vh
        } else {
            view = convertView
            vh = view.tag as ItemRowHolder
        }

        vh.label.text = countryList.get(position).rcCountryName
        return view
    }

    override fun getItem(position: Int): Any {
        return countryList.get(position)
    }

    override fun getItemId(position: Int): Long {
        return countryList.get(position).rcCountryId.toLong()
    }

    override fun getCount(): Int {
        return countryList.size
    }

    private class ItemRowHolder(row: View?) {

        val label: TextView

        init {
            this.label = row?.findViewById(R.id.txtDropDownLabel) as TextView
        }
    }
}