package com.ultimatequiz.presentation.language


import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.utils.SingleLiveEvent

class SelectLanguageViewModel(private val dataRepository: DataRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()
    val navigate = SingleLiveEvent<String>()

    init {

    }

    fun onTopBack(){
        navigate.value = "TopBack"
    }

    fun onLangEnglishClick(){
        navigate.value = "ENGLISH"
    }

    fun onLangHindiClick(){
        navigate.value = "HINDI"
    }

    fun onLangGujratiClick(){
        navigate.value = "GUJARATI"
    }

}
