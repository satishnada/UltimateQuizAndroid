package com.ultimatequiz.presentation.category

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ultimatequiz.R
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import kotlinx.android.synthetic.main.item_categories.view.*

class CategoriesListAdapter(val items: ArrayList<QuestionCategoriesRes.Category>, val context: CategoriesListActivity) :
    RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.item_categories,
                parent,
                false
            )
        )
    }

    fun setDataList(categoryList: ArrayList<QuestionCategoriesRes.Category>) {
        items.clear()
        items.addAll(categoryList)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return items.size;
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txtQuestion?.text = items.get(position).questionCategoryName
        holder.itemView.setOnClickListener {
            context.onCategoryClick()
        }
    }

}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    // Holds the TextView that will add each animal to
    val txtQuestion = view.txtQuestion
}