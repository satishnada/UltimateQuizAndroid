package com.ultimatequiz.presentation.gkchallenge

import com.google.gson.annotations.SerializedName

data class QuizLevelRes(
    @SerializedName("data")
    val quizLevelList: ArrayList<QuizLevel>,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class QuizLevel(
        @SerializedName("rcQuizLevelId")
        val quizLevelId: Int,
        @SerializedName("rcQuizCategoryId")
        val quizCategoryId: Int,
        @SerializedName("rcQuizLevelName")
        val quizLevelName: String,
        @SerializedName("rcQuizLevelQueCount")
        val quizLevelQueCount: String
    )
}