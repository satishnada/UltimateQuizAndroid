package com.ultimatequiz.presentation.selectgames

import com.google.gson.annotations.SerializedName

data class QuestionCategoriesRes(
    @SerializedName("data")
    val questionCategoryList: ArrayList<Category>,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class Category(
        @SerializedName("rcQuestionCategoryId")
        val questionCategoryId: Int,
        @SerializedName("rcQuestionCategoryName")
        val questionCategoryName: String,
        @SerializedName("rcLangId")
        val langId: Int,
        @SerializedName("rcLangName")
        val rcLangName: String
    )
}