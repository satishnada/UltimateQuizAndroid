package com.ultimatequiz.presentation.login


import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.utils.SingleLiveEvent
import com.ultimatequiz.utils.UseCaseResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AuthViewModel(private val dataRepository: DataRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()

    init {

    }



}
