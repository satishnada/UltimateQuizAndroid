package com.ultimatequiz.presentation.redeem

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityRedeemBinding
import com.ultimatequiz.databinding.ActivitySelectGamesBinding
import com.ultimatequiz.databinding.ActivityStarsInfoBinding
import org.koin.android.viewmodel.ext.android.viewModel

class RedeemActivity : AppCompatActivity() {

    private val viewModel : RedeemViewModel by viewModel()
    lateinit var  binding : ActivityRedeemBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@RedeemActivity,R.layout.activity_redeem)
        binding.mRedeemViewModel = viewModel
        initViewModel()
    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, RedeemActivity::class.java)
        }
    }

    private fun initViewModel(){

        viewModel.navigate.observe(this, Observer() {
            if (it == "GK_QUIZ"){
                //startActivity(GkChallengeLevelActivity.getInstance(this).putExtra("IS_FROM",2))
            }else if (it == "QUIZ"){
                //startActivity(QuizActivity.getInstance(this).putExtra("IS_FROM",1))
            }else if (it == "SPINNER"){
                //startActivity(QuizActivity.getInstance(this))
            }else if(it == "TopBack"){
                finish()
            }
        })

    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }
}
