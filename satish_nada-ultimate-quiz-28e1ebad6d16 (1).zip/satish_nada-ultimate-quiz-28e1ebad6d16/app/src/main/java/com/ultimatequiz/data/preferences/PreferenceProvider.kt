package com.ultimatequiz.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager

private const val USER_NAME = "USER_NAME"
private const val USER_ID = "USER_ID"
private const val DEVICE_TOKEN = "DEVICE_TOKEN"
private const val AUTH_TOKEN = "AUTH_TOKEN"
private const val SESSION = "SESSION"

class PreferenceProvider(context: Context) {

    private val appContext = context.applicationContext

    private val preference: SharedPreferences get() = PreferenceManager.getDefaultSharedPreferences(appContext)

    fun setUserId(userId : String){
        preference.edit().putString(USER_ID, userId).apply()
    }

    fun setUserName(userName : String){
        preference.edit().putString(USER_NAME, userName).apply()
    }

    fun setDeviceToken(userToken : String){
        preference.edit().putString(DEVICE_TOKEN, userToken).apply()
    }

    fun getUserId(): String? {
        return preference.getString(USER_ID, "")
    }

    fun getUserName(): String? {
        return preference.getString(USER_NAME, "")
    }

    fun getDeviceToken(): String? {
        return preference.getString(DEVICE_TOKEN, "")
    }

    fun setAuthToken(authToken : String){
        preference.edit().putString(AUTH_TOKEN, authToken).apply()
    }

    fun getAuthToken(): String? {
        return preference.getString(AUTH_TOKEN, "")
    }

    fun setSession(session : Boolean){
        preference.edit().putBoolean(SESSION, session).apply()
    }

    fun getSession(): Boolean? {
        return preference.getBoolean(SESSION, false)
    }

    fun clearPreferencesData() {
        val editor = preference.edit()
        editor.clear()
        editor.apply()
    }

}