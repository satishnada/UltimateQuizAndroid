package com.ultimatequiz.presentation.dashboard

import com.google.gson.annotations.SerializedName

data class GetPropertyByuserReqModel(
        @SerializedName("Authorization") var Authorization: String = "",
        @SerializedName("userId") var userId: String = "",
        @SerializedName("ClientID") var ClientID: String = ""
)