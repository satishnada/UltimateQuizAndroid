package com.ultimatequiz.presentation.statsinfo


import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.utils.SingleLiveEvent

class StatsInfoViewModel(private val dataRepository: DataRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()
    val navigate = SingleLiveEvent<String>()

    init {

    }

    fun onTopBack(){
        navigate.value = "TopBack"
    }

    fun onGkQuiz(){
        navigate.value = "GK_QUIZ"
    }

    fun onSpinnerClick(){
        navigate.value = "SPINNER"
    }

    fun onQuizClick(){
        navigate.value = "QUIZ"
    }

}
