package com.ultimatequiz.presentation.gkchallenge

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ultimatequiz.R
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import kotlinx.android.synthetic.main.item_gk_challenge_level.view.*

class GkChallengeLevelAdapter(val items: ArrayList<QuizLevelRes.QuizLevel>, val context: Context) :
    RecyclerView.Adapter<ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.item_gk_challenge_level,
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return items.size;
    }

    fun setDataList(quizLevelList: ArrayList<QuizLevelRes.QuizLevel>) {
        items.clear()
        items.addAll(quizLevelList)
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.txtLevel?.text = items.get(position).quizLevelId.toString()
        holder.txtQuestion?.text = items.get(position).quizLevelName
        holder.txtQuestionValue?.text = items.get(position).quizLevelQueCount
    }

}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    // Holds the TextView that will add each animal to
    val txtLevel = view.txtLevel
    val txtQuestion = view.txtQuestion
    val txtQuestionValue = view.txtQuestionValue
}