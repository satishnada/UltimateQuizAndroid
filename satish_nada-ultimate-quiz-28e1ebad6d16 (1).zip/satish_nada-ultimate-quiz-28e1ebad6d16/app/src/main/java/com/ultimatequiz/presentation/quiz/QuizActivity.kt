package com.ultimatequiz.presentation.quiz

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityQuizBinding
import com.ultimatequiz.presentation.category.CategoriesListActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import org.koin.android.viewmodel.ext.android.viewModel

class QuizActivity : AppCompatActivity() {

    val TAG = QuizActivity.javaClass.canonicalName
    private val viewModel: QuizViewModel by viewModel()
    lateinit var binding: ActivityQuizBinding
    private val viewModelApi: LoginViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@QuizActivity, R.layout.activity_quiz)
        binding.mQuizViewModel = viewModel
        initViewModel()
    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, QuizActivity::class.java)
        }
    }

    private fun initViewModel() {

        val isFrom: Int = intent.getIntExtra("IS_FROM", 0)

        if (isFrom == 1) {
            binding.txtQuestionNo.visibility = View.GONE
            binding.llCorrect.visibility = View.VISIBLE
            binding.llWrong.visibility = View.VISIBLE
            binding.llBalance.visibility = View.VISIBLE
            viewModelApi.getQuestionForUser("rcapp/rest/getQuestionForUser/1/1/1")
        } else {
            binding.txtQuestionNo.visibility = View.VISIBLE
            binding.llCorrect.visibility = View.VISIBLE
            binding.llWrong.visibility = View.VISIBLE
            binding.llBalance.visibility = View.VISIBLE
            viewModelApi.getQuestionForGKUser("rcapp/rest/getQuestionForUser/1/1/1")
        }

        viewModel.navigate.observe(this, Observer() {
            if (it == "SELECT_ANSWER_CORRECT") {
                showDialogForCorrectAnswer("")
            } else if (it == "SELECT_ANSWER_WRONG") {
                showDialogForWrongAnswer("")
            } else if (it == "SELECT_TIME_OUT") {
                showDialogForTimeOut("")
            } else if (it == "SELECT_BREAK_TIME") {
                showDialogForBreakTime("")
            } else if (it == "TOP_BACK") {
                finish()
            }
        })

        viewModelApi.quizQuestionRes.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.questionList)

        })

        viewModelApi.showError.observe(this, Observer { showError ->
            if (showError.contains("HTTP 401")){
                viewModelApi.getAccessToken()
            }else{
                Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
            }
        })

        viewModelApi.accessTokenResModel.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            viewModelApi.saveToken(it.accessToken)
            viewModelApi.getQuestionForUser("rcapp/rest/getQuestionForUser/1/1/1")
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

    }

    private fun showDialogForCorrectAnswer(title: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_correct_answer)
        val btnNext = dialog.findViewById(R.id.rlNext) as RelativeLayout
        btnNext.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showDialogForWrongAnswer(title: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_wrong_answer)
        val btnNext = dialog.findViewById(R.id.rlNext) as RelativeLayout

        btnNext.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showDialogForTimeOut(title: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_time_out)

        val btnClose = dialog.findViewById(R.id.rlClose) as RelativeLayout

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showDialogForBreakTime(title: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_break_time)

        val btnClose = dialog.findViewById(R.id.rlClose) as RelativeLayout

        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

}
