package com.ultimatequiz.presentation.login

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.data.preferences.PreferenceProvider
import com.ultimatequiz.databinding.ActivityLoginBinding
import com.ultimatequiz.presentation.dashboard.DashboardActivity
import com.ultimatequiz.utils.Preferences
import kotlinx.android.synthetic.main.activity_login.*
import org.koin.android.ext.android.inject
import org.koin.android.viewmodel.ext.android.viewModel
import java.util.*
import kotlin.collections.ArrayList


class LoginActivity : AppCompatActivity() {

    private val viewModel: LoginViewModel by viewModel()
    lateinit var binding: ActivityLoginBinding
    private val TAG = LoginActivity.javaClass.canonicalName
    private var countryList = ArrayList<CountriesRes.Country>()
    private var sltCountryId: Int = 0

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, LoginActivity::class.java)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@LoginActivity, R.layout.activity_login)
        binding.loginViewModel = viewModel
        binding.loginDataModel = LoginReqModel()
        initViewModel()
    }

    private fun initViewModel() {

        val isFrom: Int = intent.getIntExtra("IS_FROM", 0)

        if (isFrom == 1) {
            binding.rlSelectCountry.visibility = View.VISIBLE
            binding.imgBackArrow.visibility = View.INVISIBLE
            binding.imgProfileEdit.visibility = View.INVISIBLE
        } else {
            binding.rlSelectCountry.visibility = View.GONE
            binding.imgBackArrow.visibility = View.VISIBLE
            binding.imgProfileEdit.visibility = View.VISIBLE
        }

        viewModel.navigateToDashboard.observe(this, Observer {
            if (it == "ON_LOGIN_CLICK") {
                if (edtName.text.toString().trim().isEmpty()) {
                    Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
                } else if (sltCountryId < 0) {
                    Toast.makeText(this, "Please select country", Toast.LENGTH_SHORT).show()
                } else {
                    var loinRequest: LoginReqModel = LoginReqModel(
                        edtName.text.toString(),
                        UUID.randomUUID().toString(),
                        sltCountryId.toString()
                    )
                    showProgress()
                    viewModel.doLogin(loinRequest)
                }
            } else if (it == "ON_COUNTRY_SELECTION") {
                Toast.makeText(this, "Select Country", Toast.LENGTH_SHORT).show()
            } else {
                finish()
            }
        })

        // Observe showError value and display the error message as a Toast
        viewModel.showError.observe(this, Observer { showError ->
            Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
        })

        viewModel.navigateToDashboard.observe(this, Observer {
            Toast.makeText(this, "Successfully Login", Toast.LENGTH_SHORT).show()
        })

        viewModel.loginResModel.observe(this, Observer {
            showProgress()
            //if (!it.statusCode.equals("EDB", true)) {
                Log.e(TAG, it.toString())
                Toast.makeText(this, it.statusMessage, Toast.LENGTH_SHORT).show()
                viewModel.saveSession(true)
                startActivity(DashboardActivity.getInstance(this))
                finish()
            //} else {
            //    Toast.makeText(this, it.statusMessage, Toast.LENGTH_SHORT).show()
            //}
        })

        //viewModel.getAccessToken()

        viewModel.accessTokenResModel.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            Preferences.saveAccessToken(this, it.accessToken)
            viewModel.saveToken(it.accessToken)
            viewModel.getCountryList()
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

        viewModel.countriesRes.observe(this, Observer {
            showProgress()
            if (it.statusCode == "SUCCESS") {
                Log.e(TAG, "Country DATA  " + it.countryList.toString())
                countryList = it.countryList;
                val sectionAdapter = CountrySpinnerListAdapter(this, countryList)
                binding.spinnerCountry.adapter = sectionAdapter

                sltCountryId = countryList.get(0).rcCountryId
                binding.txtCountry.text = countryList.get(0).rcCountryName

            } else {
                Toast.makeText(this, it.statusMessage, Toast.LENGTH_SHORT).show()
            }
        })

        binding.txtCountry.setOnClickListener {
            binding.spinnerCountry.performClick()
        }

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

        binding.spinnerCountry?.setOnItemSelectedListener(object :
            AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.i(TAG, "onNothingSelected: ")
            }

            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                sltCountryId = countryList.get(position).rcCountryId
                binding.txtCountry.text = countryList.get(position).rcCountryName
                Log.i(TAG, "onItemSelected: " + countryList.get(position).rcCountryName)
            }
        });

        viewModel.getCountryList()

    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }
}
