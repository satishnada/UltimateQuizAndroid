package com.ultimatequiz.presentation.statsinfo

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityStarsInfoBinding
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel

class StatsInfoActivity : AppCompatActivity() {

    private val viewModel : StatsInfoViewModel by viewModel()
    lateinit var  binding : ActivityStarsInfoBinding
    private val viewModelApi: LoginViewModel by viewModel()
    val TAG = StatsInfoActivity.javaClass.canonicalName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@StatsInfoActivity,R.layout.activity_stars_info)
        binding.mStatsInfoViewModel = viewModel
        initViewModel()
    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, StatsInfoActivity::class.java)
        }
    }

    private fun initViewModel(){

        viewModel.navigate.observe(this, Observer() {
            if (it == "GK_QUIZ"){
                //startActivity(GkChallengeLevelActivity.getInstance(this).putExtra("IS_FROM",2))
            }else if (it == "QUIZ"){
                //startActivity(QuizActivity.getInstance(this).putExtra("IS_FROM",1))
            }else if (it == "SPINNER"){
                //startActivity(QuizActivity.getInstance(this))
            }else if(it == "TopBack"){
                finish()
            }
        })

        binding.imgQuiz.setOnClickListener {
            showProgress()
            viewModelApi.getQuizStateInfo("rcapp/rest/getQuizStateByUser/1")
        }

        binding.imgGKChallenge.setOnClickListener {
            showProgress()
            viewModelApi.getQuizStateInfo("rcapp/rest/getQuizStateByUser/1")
        }

        viewModelApi.quizStateInfoRes.observe(this, Observer {
            showProgress()
            Log.e(TAG, "DATA SIZE " + it.quizStateInfo.correctAns)
            binding.txtTotalCorrectQue.text = it.quizStateInfo.correctAns.toString()
            binding.txtTotalPlayedQue.text = it.quizStateInfo.totalPlayed.toString()
            binding.txtTotalWrongQue.text = it.quizStateInfo.wrongAns.toString()
        })

        viewModelApi.showError.observe(this, Observer { showError ->
            showProgress()
            if (showError.contains("HTTP 401")){
                viewModelApi.getAccessToken()
            }else{
                Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
            }
        })

        viewModelApi.accessTokenResModel.observe(this, Observer {
            showProgress()
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            Preferences.saveAccessToken(this, it.accessToken)
            viewModelApi.saveToken(it.accessToken)
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

    }

    private fun showProgress(){
        if (binding.progress.isVisible){
            binding.progress.visibility = View.GONE
        }else{
            binding.progress.visibility = View.VISIBLE
        }
    }
}
