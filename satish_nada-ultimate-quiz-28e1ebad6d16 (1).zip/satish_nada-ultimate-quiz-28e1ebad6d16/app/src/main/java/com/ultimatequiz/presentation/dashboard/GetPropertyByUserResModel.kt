package com.ultimatequiz.presentation.dashboard


import com.google.gson.annotations.SerializedName

data class GetPropertyByUserResModel(
    @SerializedName("Data")
    val `data`: List<Data>,
    @SerializedName("Data1")
    val data1: Any?, // null
    @SerializedName("ErrorCode")
    val errorCode: Int, // 1
    @SerializedName("FlagETL")
    val flagETL: Boolean, // false
    @SerializedName("IsSuccess")
    val isSuccess: Boolean, // true
    @SerializedName("Message")
    val message: Any?, // null
    @SerializedName("ResrevationActivityFromLastTwodays")
    val resrevationActivityFromLastTwodays: Any?, // null
    @SerializedName("RevenueBookingYOYChart")
    val revenueBookingYOYChart: Any?, // null
    @SerializedName("strCompanyHierachical")
    val strCompanyHierachical: Any?, // null
    @SerializedName("strCompsetRateData")
    val strCompsetRateData: Any?, // null
    @SerializedName("strCompsetRateDataYesterday")
    val strCompsetRateDataYesterday: Any?, // null
    @SerializedName("strCurrentMonthAndYearStats")
    val strCurrentMonthAndYearStats: Any?, // null
    @SerializedName("strDailyStats")
    val strDailyStats: Any?, // null
    @SerializedName("strDailyStatsTotal")
    val strDailyStatsTotal: Any?, // null
    @SerializedName("strDailySummary")
    val strDailySummary: Any?, // null
    @SerializedName("strEventDetails")
    val strEventDetails: Any?, // null
    @SerializedName("strFromCurrentMonthAndYearStats")
    val strFromCurrentMonthAndYearStats: Any?, // null
    @SerializedName("strGroupNameDetails")
    val strGroupNameDetails: Any?, // null
    @SerializedName("strGuestNameHierachical")
    val strGuestNameHierachical: Any?, // null
    @SerializedName("strHotDates")
    val strHotDates: Any?, // null
    @SerializedName("strMarketSegmentPickUp")
    val strMarketSegmentPickUp: Any?, // null
    @SerializedName("strMarketSegmentPickUpMarketSegment")
    val strMarketSegmentPickUpMarketSegment: Any?, // null
    @SerializedName("strMarketSegmentPickUpMarketSegmentADR")
    val strMarketSegmentPickUpMarketSegmentADR: Any?, // null
    @SerializedName("strMonthMTDTable")
    val strMonthMTDTable: Any?, // null
    @SerializedName("strMonthOTBTable")
    val strMonthOTBTable: Any?, // null
    @SerializedName("strMonthYearData")
    val strMonthYearData: Any?, // null
    @SerializedName("strMonthlyMarketSegment")
    val strMonthlyMarketSegment: Any?, // null
    @SerializedName("strMonthlyStats")
    val strMonthlyStats: Any?, // null
    @SerializedName("strMonthlyStatsTotal")
    val strMonthlyStatsTotal: Any?, // null
    @SerializedName("strMonthlySummary")
    val strMonthlySummary: Any?, // null
    @SerializedName("strOTBMarketSegment")
    val strOTBMarketSegment: Any?, // null
    @SerializedName("strPickUpRateShop")
    val strPickUpRateShop: Any?, // null
    @SerializedName("strPickup7ADR")
    val strPickup7ADR: Any?, // null
    @SerializedName("strPickup7ADRTotal")
    val strPickup7ADRTotal: Any?, // null
    @SerializedName("strPickup7OTB")
    val strPickup7OTB: Any?, // null
    @SerializedName("strPickup7OTBTotal")
    val strPickup7OTBTotal: Any?, // null
    @SerializedName("strPickup7RevenueTotal")
    val strPickup7RevenueTotal: Any?, // null
    @SerializedName("strPickupADR")
    val strPickupADR: Any?, // null
    @SerializedName("strPickupADRTotal")
    val strPickupADRTotal: Any?, // null
    @SerializedName("strPickupCalendarDates")
    val strPickupCalendarDates: Any?, // null
    @SerializedName("strPickupCalendarDays")
    val strPickupCalendarDays: Any?, // null
    @SerializedName("strPickupOTB")
    val strPickupOTB: Any?, // null
    @SerializedName("strPickupOTBTotal")
    val strPickupOTBTotal: Any?, // null
    @SerializedName("strPickupRevenueTotal")
    val strPickupRevenueTotal: Any?, // null
    @SerializedName("strPortfolioDetails")
    val strPortfolioDetails: Any?, // null
    @SerializedName("strPricingAnalysis")
    val strPricingAnalysis: Any?, // null
    @SerializedName("strPropertyLogo")
    val strPropertyLogo: Any?, // null
    @SerializedName("strRatePlanHierachical")
    val strRatePlanHierachical: Any?, // null
    @SerializedName("strRatePlanRevenue")
    val strRatePlanRevenue: Any?, // null
    @SerializedName("strRatePlanRevenueLastYear")
    val strRatePlanRevenueLastYear: Any?, // null
    @SerializedName("strResrevationActivityFromLastTwodays")
    val strResrevationActivityFromLastTwodays: Any?, // null
    @SerializedName("strStayDateLOS")
    val strStayDateLOS: Any?, // null
    @SerializedName("strTodayTable")
    val strTodayTable: Any?, // null
    @SerializedName("strTotCurrentMonthAndYearStats")
    val strTotCurrentMonthAndYearStats: Any?, // null
    @SerializedName("strTotMonthToDatePickupYestForecastRateShop")
    val strTotMonthToDatePickupYestForecastRateShop: Any?, // null
    @SerializedName("strTotPickupYestForecastRateShop")
    val strTotPickupYestForecastRateShop: Any?, // null
    @SerializedName("strTotalADR")
    val strTotalADR: Any?, // null
    @SerializedName("strTotalADRTotal")
    val strTotalADRTotal: Any?, // null
    @SerializedName("strTotalOTB")
    val strTotalOTB: Any?, // null
    @SerializedName("strTotalOTBTotal")
    val strTotalOTBTotal: Any?, // null
    @SerializedName("strTotalRevenueTotal")
    val strTotalRevenueTotal: Any?, // null
    @SerializedName("strYearlyMarketSegment")
    val strYearlyMarketSegment: Any?, // null
    @SerializedName("strYesterdayTable")
    val strYesterdayTable: Any? // null
) {
    data class Data(
        @SerializedName("AboutProperty")
        val aboutProperty: String,
        @SerializedName("ClientID")
        val clientID: String, // 00000000-0000-0000-0000-000000000000
        @SerializedName("EncryptedPropertyId")
        val encryptedPropertyId: String, // suiveJlxgJFYNw9DkehIE-kjrKiixfikeFAoz0eF2xiFi5OMIAw3x91_3J3XDXCx0
        @SerializedName("EncryptedPropertyName")
        val encryptedPropertyName: String, // 7vKSkEY7BKb9Dc2D1ahm5A2
        @SerializedName("HotelCode")
        val hotelCode: String, // CZTX615
        @SerializedName("IsSync")
        val isSync: Boolean, // true
        @SerializedName("PortfolioID")
        val portfolioID: String, // 00000000-0000-0000-0000-000000000000
        @SerializedName("PortfolioName")
        val portfolioName: Any?, // null
        @SerializedName("PropertyID")
        val propertyID: String, // 91adca65-2006-4f36-b25a-f8eb4fade581
        @SerializedName("PropertyLogo")
        val propertyLogo: String, // e4a401c9_cdc8_4f17_adfb_c0162d11defb.jpg
        @SerializedName("PropertyName")
        val propertyName: String, // CZTX615
        @SerializedName("PropertyNameHotelCodeFranchise")
        val propertyNameHotelCodeFranchise: String, // CZTX615 / CZTX615 / Choice
        @SerializedName("Term")
        val term: String, // Choice
        @SerializedName("TmpPropertyLogo")
        val tmpPropertyLogo: String, // /Assets/img/City-Hotel-icon.jpg
        @SerializedName("UserID")
        val userID: String // 5aa23f77-27ea-452c-922f-14053f28e62b
    )
}