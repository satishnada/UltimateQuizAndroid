package com.ultimatequiz.data.repositories

import com.ultimatequiz.presentation.gkchallenge.QuizLevelRes
import com.ultimatequiz.presentation.language.LanguageRes
import com.ultimatequiz.presentation.learderboard.LeaderBoardInfoRes
import com.ultimatequiz.presentation.login.*
import com.ultimatequiz.presentation.quiz.QuizCategoriesRes
import com.ultimatequiz.presentation.quiz.QuizQuestionsRes
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import com.ultimatequiz.presentation.statsinfo.QuizStateInfoRes
import com.ultimatequiz.utils.UseCaseResult

interface DataRepository {

    suspend fun getCountryList(): UseCaseResult<CountriesRes>

    suspend fun loginAsync(loginReqModel: LoginReqModel): UseCaseResult<LoginResModel>

    suspend fun userLogout(): UseCaseResult<LoginResModel>

    suspend fun getLanguageList(): UseCaseResult<LanguageRes>

    suspend fun getAllQuizLevelList(): UseCaseResult<QuizLevelRes>

    suspend fun getQuestionCategoryList(): UseCaseResult<QuestionCategoriesRes>

    suspend fun getQuestionCategoryListByLanguageId(): UseCaseResult<QuestionCategoriesRes>

    suspend fun getQuizCategoryList(): UseCaseResult<QuizCategoriesRes>

    suspend fun getLeaderBoardInfo(): UseCaseResult<LeaderBoardInfoRes>

    suspend fun getQuizStateInfo(url:String): UseCaseResult<QuizStateInfoRes>

    suspend fun getQuestionForGKUser(url:String): UseCaseResult<QuizQuestionsRes>

    suspend fun getQuestionForUser(url:String): UseCaseResult<QuizQuestionsRes>

    suspend fun getAccessToken(tokenReqModel: TokenReqModel?): UseCaseResult<AccessTokenResModel>

}


