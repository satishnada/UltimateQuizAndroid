package com.ultimatequiz.presentation.learderboard

import com.google.gson.annotations.SerializedName

data class LeaderBoardInfoRes(
    @SerializedName("data")
    val leaderBoardsList: LeaderBoards,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class LeaderBoards(
        @SerializedName("rcLeaderBoardRanker")
        val leaderBoardRanker: ArrayList<LeaderBoard>,
        @SerializedName("rcLeaderBoardRankerList")
        val leaderBoardRankerList: ArrayList<LeaderBoard>
    )

    data class LeaderBoard(
        @SerializedName("rcUserAccountId")
        val userAccountId: Int,
        @SerializedName("rcUserId")
        val userId: Int,
        @SerializedName("rcTotalCoinEarn")
        val totalCoinEarn: Int,
        @SerializedName("rcUserName")
        val userName: String,
        @SerializedName("rcProfilePic")
        val profilePic: String
    )
}

