package com.ultimatequiz.utils

import android.content.Context
import android.content.Context.MODE_PRIVATE
import androidx.annotation.NonNull
import com.google.gson.Gson
import com.ultimatequiz.presentation.login.LoginResModel

@Suppress("unused", "deprecation")
object Preferences {
    private const val PREFERENCE_NAME = "APP_DATA"
    private const val KEY_ACCESS_TOKEN = "ACCESS_TOKEN"
    private const val KEY_LOCAL = "LOCAL"
    private const val KEY_TRAVEL_MODE = "travel_mode"
    private const val KEY_SESSION = "SESSION"
    private const val KEY_PARENT_DATA = "PARENT_DATA"

    fun saveSession(context: Context, session: Boolean) {
        context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE).edit()
            .putBoolean(KEY_SESSION, session).apply()
    }

    @NonNull
    fun loadSession(context: Context): Boolean {
        return context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE)
            .getBoolean(KEY_SESSION, false)
    }

    fun saveAccessToken(context: Context, @NonNull token: String?) {
        context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE).edit()
            .putString(KEY_ACCESS_TOKEN, token).apply()
    }

    @NonNull
    fun loadAccessToken(context: Context): String {
        return context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE)
            .getString(KEY_ACCESS_TOKEN, "")!!
    }


    /**
     * Save parent data from login
     * */
    fun saveUserData(context: Context, loginResModel: LoginResModel) {
        val parentData = Gson().toJson(loginResModel)
        context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE).edit()
            .putString(KEY_PARENT_DATA, parentData).apply()
    }


    @NonNull
    fun loadUserData(context: Context): LoginResModel {
        return Gson().fromJson(
            context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE)
                .getString(KEY_PARENT_DATA, ""), LoginResModel::class.java
        )
    }
    /**
     * Clear the saved shared preference data on logout
     * */
    fun clearPreference(context: Context) {
        context.getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE).edit().clear().apply()
    }
}