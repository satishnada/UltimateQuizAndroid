package com.ultimatequiz.presentation.language

import com.google.gson.annotations.SerializedName

data class LanguageRes(
    @SerializedName("data")
    val languageList: ArrayList<Language>,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class Language(
        @SerializedName("rcLangId")
        val langId: Int,
        @SerializedName("rcLangName")
        val langName: String,
        @SerializedName("rcLangCode")
        val langCode: String
    )
}