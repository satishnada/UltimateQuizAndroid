package com.ultimatequiz.data.remote


import com.ultimatequiz.presentation.gkchallenge.QuizLevelRes
import com.ultimatequiz.presentation.language.LanguageRes
import com.ultimatequiz.presentation.learderboard.LeaderBoardInfoRes
import com.ultimatequiz.presentation.login.AccessTokenResModel
import com.ultimatequiz.presentation.login.CountriesRes
import com.ultimatequiz.presentation.login.LoginResModel
import com.ultimatequiz.presentation.quiz.QuizCategoriesRes
import com.ultimatequiz.presentation.quiz.QuizQuestionsRes
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import com.ultimatequiz.presentation.statsinfo.QuizStateInfoRes
import retrofit2.http.*

interface WebApi {

    @GET("rcapp/rest/getAllCountry")
    suspend fun getCountryList() : CountriesRes

    @GET
    suspend fun loginAsync(@Url url:String): LoginResModel

    @POST("rcapp/oauth/token")
    suspend fun getAccessToken(@Query("grant_type") grant_type: String?,
                               @Query("username") username: String?,
                               @Query("password") password: String?
                                ) : AccessTokenResModel

    @GET("rcapp/rest/getAllQuizLevel")
    suspend fun getAllQuizLevel() : QuizLevelRes

    @GET("rcapp/rest/getLanguages")
    suspend fun getLanguages() : LanguageRes

    @GET("rcapp/rest/getQuizCategoryList")
    suspend fun getQuizCategoryList() : QuizCategoriesRes

    @GET("rcapp/rest/getQuestionCategory")
    suspend fun getQuestionCategory() : QuestionCategoriesRes

    @GET("rcapp/rest/getQuestionCategory")
    suspend fun getQuestionCategoryByLanguageId() : QuestionCategoriesRes

    @GET("rcapp/rest/getLeaderBoardInfo")
    suspend fun getLeaderBoardInfo() : LeaderBoardInfoRes

    @GET
    suspend fun getQuizStateInfo(@Url url:String) : QuizStateInfoRes

    @GET("rcapp/ano/logout")
    suspend fun userLogout() : LoginResModel

    @GET
    suspend fun getQuestionsForUser(@Url url:String) : QuizQuestionsRes

    @GET
    suspend fun getQuestionsForGKUser(@Url url:String) : QuizQuestionsRes

}