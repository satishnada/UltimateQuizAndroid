package com.ultimatequiz.utils

import android.util.Log
import com.ultimatequiz.BuildConfig

inline fun <reified TAG> dLog(message: String) {
    if (BuildConfig.DEBUG) {
        Log.d(TAG::class.java.simpleName, message)
    }
}

inline fun <reified TAG> eLog(message: String) {
    if (BuildConfig.DEBUG) {
        Log.e(TAG::class.java.simpleName, message)
    }
}

inline fun <reified TAG> eLog(message: String, ex: Exception) {
    if (BuildConfig.DEBUG) {
        Log.e(TAG::class.java.simpleName, message, ex)
    }
}

inline fun <reified TAG> iLog(message: String) {
    if (BuildConfig.DEBUG) {
        Log.i(TAG::class.java.simpleName, message)
    }
}

inline fun <reified TAG> wLog(message: String) {
    if (BuildConfig.DEBUG) {
        Log.w(TAG::class.java.simpleName, message)
    }
}

inline fun <reified TAG> vLog(message: String) {
    if (BuildConfig.DEBUG) {
        Log.v(TAG::class.java.simpleName, message)
    }
}