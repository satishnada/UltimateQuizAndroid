package com.ultimatequiz.presentation.login

import com.google.gson.annotations.SerializedName

data class LoginReqModel(
        @SerializedName("username") var username: String = "",
        @SerializedName("deviceId") var deviceId: String = "",
        @SerializedName("countryId") var countryId: String = ""
)