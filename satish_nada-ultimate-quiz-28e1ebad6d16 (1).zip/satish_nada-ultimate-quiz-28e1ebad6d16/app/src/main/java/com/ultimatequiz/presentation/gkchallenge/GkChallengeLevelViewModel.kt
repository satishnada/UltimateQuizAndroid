package com.ultimatequiz.presentation.gkchallenge


import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.utils.SingleLiveEvent

class GkChallengeLevelViewModel(private val dataRepository: DataRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()
    val navigate = SingleLiveEvent<String>()

    init {

    }

    fun onTopBack(){
        navigate.value = "TOP_BACK"
    }

    fun onSelectLevel(){
        navigate.value = "SELECT_LEVEL"
    }

}
