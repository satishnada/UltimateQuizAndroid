package com.ultimatequiz.presentation.category

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.ultimatequiz.R
import com.ultimatequiz.databinding.ActivityCategoriesListBinding
import com.ultimatequiz.databinding.ActivityGkChallengeLevelBinding
import com.ultimatequiz.databinding.ActivitySelectGamesBinding
import com.ultimatequiz.presentation.dashboard.DashboardActivity
import com.ultimatequiz.presentation.login.LoginViewModel
import com.ultimatequiz.presentation.quiz.QuizActivity
import com.ultimatequiz.presentation.selectgames.QuestionCategoriesRes
import com.ultimatequiz.utils.Preferences
import org.koin.android.viewmodel.ext.android.viewModel

class CategoriesListActivity : AppCompatActivity() {

    val TAG = CategoriesListActivity.javaClass.canonicalName
    private val viewModel : CategoriesViewModel by viewModel()
    lateinit var  binding : ActivityCategoriesListBinding
    private val viewModelApi: LoginViewModel by viewModel()
    private var categoryListAdapter : CategoriesListAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this@CategoriesListActivity,R.layout.activity_categories_list)
        binding.mCategoryViewModel = viewModel
        initViewModel()
    }

    companion object {
        fun getInstance(activity: Activity): Intent {
            return Intent(activity, CategoriesListActivity::class.java)
        }
    }

    private fun initViewModel(){

        val levelList : ArrayList<QuestionCategoriesRes.Category> = ArrayList();
        categoryListAdapter =  CategoriesListAdapter(levelList,this)
        binding.recyclerViewCategory.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewCategory.adapter = categoryListAdapter

        viewModel.navigateToDashboard.observe(this, Observer() {
            if (it == "SELECT_LEVEL"){
                finish()
            }else if(it == "TOP_BACK"){
                finish()
            }
        })

        viewModelApi.getQuestionCategoryList()

        viewModelApi.questionCategoriesRes.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.questionCategoryList)
            categoryListAdapter?.setDataList(it.questionCategoryList)
        })

        viewModelApi.showError.observe(this, Observer { showError ->
            if (showError.contains("HTTP 401")){
                viewModelApi.getAccessToken()
            }else{
                Toast.makeText(this, showError, Toast.LENGTH_SHORT).show()
            }
        })

        viewModelApi.accessTokenResModel.observe(this, Observer {
            Log.e(TAG, "DATA SIZE " + it.accessToken)
            viewModelApi.saveToken(it.accessToken)
            viewModelApi.getQuestionCategoryList()
        })

        viewModel.showError.observe(this, Observer {
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        })

    }

    fun onCategoryClick(){
        startActivity(QuizActivity.getInstance(this).putExtra("IS_FROM",1))
    }

}
