package com.ultimatequiz.presentation.quiz


import androidx.lifecycle.MutableLiveData
import com.ultimatequiz.data.repositories.DataRepository
import com.ultimatequiz.presentation.base.BaseViewModel
import com.ultimatequiz.utils.SingleLiveEvent

class QuizViewModel(private val dataRepository: DataRepository) : BaseViewModel() {

    val showLoading = MutableLiveData<Boolean>()
    val showError = SingleLiveEvent<String>()
    val navigate = SingleLiveEvent<String>()

    init {

    }

    fun onTopBack(){
        navigate.value = "TOP_BACK"
    }

    fun onSelectAnswerCorrect(){
        navigate.value = "SELECT_ANSWER_CORRECT"
    }

    fun onSelectAnswerWrong(){
        navigate.value = "SELECT_ANSWER_WRONG"
    }

    fun onSelectBreakTime(){
        navigate.value = "SELECT_BREAK_TIME"
    }

    fun onSelectTimeOut(){
        navigate.value = "SELECT_TIME_OUT"
    }

}
