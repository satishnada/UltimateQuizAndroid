package com.ultimatequiz.presentation.login

import com.google.gson.annotations.SerializedName

data class CountriesRes(
    @SerializedName("data")
    val countryList: ArrayList<Country>,
    @SerializedName("statusCode")
    val statusCode: String, // "SUCCESS"
    @SerializedName("statusMessage")
    val statusMessage: String
) {
    data class Country(
        @SerializedName("rcCountryId")
        val rcCountryId: Int,
        @SerializedName("rcCountryName")
        val rcCountryName: String
    )
}